﻿
using Newtonsoft.Json;
using ShopApp.Models.Backend.Login;
using System.Text;
using ShopApp.Models.Config;
using Microsoft.Extensions.Configuration;

namespace ShopApp.Services;

public class SecurityService
{
    private HttpClient client;
    private Settings settings;
    public SecurityService(HttpClient client, IConfiguration configuration)
    {
        this.client = client;
        settings = configuration.GetRequiredSection(nameof(Settings)).Get<Settings>();
    }

    public async Task<bool> Login(string email, string password)
    {
        var url = $"{settings.UrlBase}/api/usuario/login";
        var loginRequest = new LoginRequest
        {
            Email = email,
            Password = password
        };

        var json = JsonConvert.SerializeObject(loginRequest);
        var content = new StringContent(json, Encoding.UTF8, "application/json");
        var response = await client.PostAsync(url, content);

        if (!response.IsSuccessStatusCode) return false;

        var jsonResultado = await response.Content.ReadAsStringAsync();
        var resultado = JsonConvert.DeserializeObject<UserResponse>(jsonResultado);

        Preferences.Set("accesstoken", resultado.Token);
        Preferences.Set("userid", resultado.Id);
        Preferences.Set("email", resultado.Email);
        Preferences.Set("Nombre", $"{resultado.Name}  {resultado.LastName}");
        Preferences.Set("Telefono", resultado.Phone);
        Preferences.Set("username", resultado.UserName);

        return true;
    }

    public async Task<bool> RegisterUser(string nombre, string apellido, string email, string userName, string telefono, string password)
    {
        var url = $"{settings.UrlBase}/api/usuario/registrar";
        var newUserRequest = new NewUserRequest
        {
            Name = nombre,
            LastName = apellido,
            Email = email,
            UserName = userName,
            Phone = telefono,
            Password = password
        };

        var json = JsonConvert.SerializeObject(newUserRequest);
        var content = new StringContent(json, Encoding.UTF8, "application/json");
        var response = await client.PostAsync(url, content);

        if (!response.IsSuccessStatusCode) return false;

        var jsonResultado = await response.Content.ReadAsStringAsync();
        var resultado = JsonConvert.DeserializeObject<UserResponse>(jsonResultado);

        Preferences.Set("accesstoken", resultado.Token);
        Preferences.Set("userid", resultado.Id);
        Preferences.Set("email", resultado.Email);
        Preferences.Set("nombre", $"{resultado.Name}  {resultado.LastName}");
        Preferences.Set("telefono", resultado.Phone);
        Preferences.Set("username", resultado.UserName);

        return true;
    }



}

